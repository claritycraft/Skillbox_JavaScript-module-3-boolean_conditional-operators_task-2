//  оператор &&, потому что  используется для объединения двух условий, чтобы проверить диапазон значений.Чтобы и первая, и вторая часть условия были истинными одновременно

let carHorsPower = prompt("Введите ЛС автомобиля:");

if (carHorsPower < 100) {
  console.log("Ввод:", carHorsPower);
  console.log("Вывод: Сумма налога:", carHorsPower * 12);
} else if (carHorsPower >= 100 && carHorsPower < 125) {
  console.log("Ввод:", carHorsPower);
  console.log("Вывод: Сумма налога:", carHorsPower * 25);
} else if (carHorsPower >= 125 && carHorsPower < 150) {
  console.log("Ввод:", carHorsPower);
  console.log("Вывод: Сумма налога:", carHorsPower * 35);
} else if (carHorsPower >= 150 && carHorsPower < 175) {
  console.log("Ввод:", carHorsPower);
  console.log("Вывод: Сумма налога:", carHorsPower * 45);
} else if (carHorsPower >= 175 && carHorsPower < 200) {
  console.log("Ввод:", carHorsPower);
  console.log("Вывод: Сумма налога:", carHorsPower * 50);
} else if (carHorsPower >= 200 && carHorsPower < 225) {
  console.log("Ввод:", carHorsPower);
  console.log("Вывод: Сумма налога:", carHorsPower * 65);
} else if (carHorsPower >= 225 && carHorsPower < 250) {
  console.log("Ввод:", carHorsPower);
  console.log("Вывод: Сумма налога:", carHorsPower * 75);
} else if (carHorsPower >= 250) {
  console.log("Ввод:", carHorsPower);
  console.log("Вывод: Сумма налога:", carHorsPower * 150);
}
